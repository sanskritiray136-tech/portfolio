# Sanskriti Ray — Celestial Portfolio

A responsive, single-page portfolio website with a celestial visual style, animated details, clickable project and achievement cards, skill tabs, achievement filters, and a mobile-friendly layout.

## Open locally
1. Extract this folder.
2. Open `index.html` in a modern browser.

No build tools or installation are required.

## Current portfolio content
- Education: VIT B.Tech CSE (AI & ML); Ralli International School, Delhi — completed in 2026 (Physics, Chemistry, Mathematics, Computer Science).
- Interests: AI & ML, technology for social impact, Model United Nations, public speaking, singing, and artistic creativity.
- Skills/tools: Python, HTML, CSS, Java, UI/UX design, Figma, Canva, Git, and GitHub.
- Achievements: Olympiad medals, Mathsquerade first prize, HackGrid Gravitas second runner-up, workshops, PCRA state-level recognition, and MUN roles/awards.
- Projects: Oreo personal chatbot, Khetinex, and AquaSense (in progress).
- Contact: sanskritiray136@gmail.com.

## Customize
Edit `index.html` in any text editor. Update project descriptions with the actual implementation details and links when available. LinkedIn: https://www.linkedin.com/in/sanskriti-ray-58428a40a
- GitHub: https://github.com/sanskritiray136-tech
- The portrait photo has been removed from the opening hero section, as requested.

## Publish
You can deploy the folder as a static site using GitHub Pages, Netlify, or another static hosting provider.


## Project links
- **Oreo:** The supplied `my_agent (1).html` has been added as `oreo.html`. Open it from the portfolio folder. It asks for your own Groq API key to run the chatbot.
- **Khetinex:** The portfolio card opens https://fantasticfive-hg-26.vercel.app/ in a new tab.
